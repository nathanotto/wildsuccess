1. Fears of failure are planning constraints
2. Every human wants to contribute and be acknowledged
3. Primary data for truth; grounded assessment for action
4. Repetitions become systems
a. repeated failure = prevention systems
b. repeated value = solved problem
5. people need agency like they need air
6. Wild Success grows because people experience better value + easier cooperation + alignment 
7. Defective behavior (in the sense of Tit-for-Tat iterated prisoner's dilemma) is detected and corrected immediately
a. Solo implementation: Me-Now (MN) vs Me-Future (MF). Cooperation Points earned at commitment, lost at defection. Swift to punish, swift to forgive.
b. Collaborative implementation: extends to interpersonal commitments; CP history becomes cooperation signal
8. Reputation is the recent accumulation of what other people experience with you
9. We can agree on values but differ on vision ( that expresses those values)
a. We can agree on vision but differ on plans  to achieve that vision
i. We can agree on values, vision, and plans but differ on actions to implement that plan
10. None of those differences below values alignment impairs our connection. We each take action according to our lights.
11. Real-time, trustable data is essential
12. We give each other kind, objective feedback, and we accept it as a gift
